 import { useState } from 'react';
import { ethers } from 'ethers';

export default function ConnectWallet({ onConnect }) {
  const [walletAddress, setWalletAddress] = useState(null);

  async function connectWallet() {
    if (!window.ethereum) {
      alert("Please install MetaMask");
      return;
    }

    try {
      const provider = new ethers.BrowserProvider(window.ethereum);
      const accounts = await provider.send("eth_requestAccounts", []);
      const signer = await provider.getSigner();
      setWalletAddress(accounts[0]);
      onConnect({ provider, signer, address: accounts[0] });
    } catch (error) {
      console.error("Connection error:", error);
    }
  }

  return (
    <div>
      <button onClick={connectWallet} style={{ padding: "10px 20px" }}>
        {walletAddress ? `Connected: ${walletAddress.slice(0, 6)}...` : "Connect Wallet"}
      </button>
    </div>
  );
}
 