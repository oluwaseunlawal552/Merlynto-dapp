import { ethers } from "ethers";
import tokenAbi from "./abis/token.json";

// your deployed Merlynto token address
const tokenAddress = "0x5E74528a5214762dc1b2705e21e6D2aCb94239F7";

export function getTokenContract(signerOrProvider) {
  return new ethers.Contract(tokenAddress, tokenAbi, signerOrProvider);
}
