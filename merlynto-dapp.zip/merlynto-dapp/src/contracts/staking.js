import { ethers } from "ethers";
import stakingAbi from "./abis/staking.json";

// your deployed staking contract address
const stakingAddress = "0x1ED1e6cf51b75851Dc628C4BAE3fFeCF69B747F5";

export function getStakingContract(signerOrProvider) {
  return new ethers.Contract(stakingAddress, stakingAbi, signerOrProvider);
}
