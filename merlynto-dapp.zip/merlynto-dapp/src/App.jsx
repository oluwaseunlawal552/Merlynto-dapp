function App() {
  return (
    <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
      <div className="text-center space-y-4">
        <h1 className="text-3xl font-bold">🎉 Tailwind is Working!</h1>
        <p className="text-lg text-gray-300">Let’s finish your Merlynto DApp now.</p>
        <button className="bg-blue-600 hover:bg-blue-700 px-6 py-2 rounded-full text-white">
          Test Button
        </button>
      </div>
    </div>
  );
}

export default App;
